clear,clc
load onlineRun1
onlineData = data
load offlineRun1
offlineData = data
i = 1;

calibTimeOnline = onlineData.getElement('calibration time').Values.Data(:);
calibTimeOffline = offlineData.getElement('calibration time').Values.Data(:);
calibTime = calibTimeOnline(end);
calibSamples = calibTime*1000+1;
tOnline = (1:length(calibTimeOnline)-calibSamples+1)/1000;
tOffline = (1:length(calibTimeOffline))/1000;

%% Attitude - Gimbal Vs FDM
phi_fdm_online =        rad2deg(onlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Phi_rad.data(calibSamples:end));
theta_fdm_online =      rad2deg(onlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Theta_rad.data(calibSamples:end));
psi_fdm_online =        rad2deg(onlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Psi_rad.data(calibSamples:end));
phi_gimbal_online =     rad2deg(onlineData.getElement('Gimbal Angles').Values.gimbalPhi.Data(calibSamples:end));
theta_gimbal_online =   rad2deg(onlineData.getElement('Gimbal Angles').Values.gimbalTheta.Data(calibSamples:end));
psi_gimbal_online =     rad2deg(onlineData.getElement('Gimbal Angles').Values.gimbalPsi.Data(calibSamples:end));

figure(i); i = i+1;
p = plot(tOnline(:),[phi_fdm_online(:),phi_gimbal_online(:)],'lineWidth',2)
return
grid, legend, xlabel("time (s)"), ylabel("phi (deg)"), title("$\phi$");
figure(i); i = i+1;
plot(tOnline(:),[theta_fdm_online(:),theta_gimbal_online(:)])

figure(i); i = i+1;
plot(tOnline(:),[psi_fdm_online(:),psi_gimbal_online(:)])

%% Attitude - FDM online vs FDM online
phi_fdm_offline =        rad2deg(offlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Phi_rad.data);
theta_fdm_offline =      rad2deg(offlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Theta_rad.data);
psi_fdm_offline =        rad2deg(offlineData.getElement('FDM States').Values.Attitude_States.ATT_Euler.Psi_rad.data);

figure(i); i = i+1;
plot(tOnline(:),phi_fdm_online(:),tOffline,phi_fdm_offline(:))

figure(i); i = i+1;
plot(tOnline(:),theta_fdm_online(:),tOffline,theta_fdm_offline(:))

figure(i); i = i+1;
plot(tOnline(:),psi_fdm_online(:),tOffline,psi_fdm_offline(:))

%% Gyro - online PIXHAWK vs Virtual
gyroX_virtual_online =      onlineData.getElement('Virtual IMU').Values.gyro.gyroX.Data(calibSamples:end);
gyroY_virtual_online =      onlineData.getElement('Virtual IMU').Values.gyro.gyroY.Data(calibSamples:end);
gyroZ_virtual_online =      onlineData.getElement('Virtual IMU').Values.gyro.gyroZ.Data(calibSamples:end);
gyroX_pix_online =      onlineData.getElement('FCC Data').Values.Internal_Data.gyroX.Data(calibSamples:end);
gyroY_pix_online =      onlineData.getElement('FCC Data').Values.Internal_Data.gyroY.Data(calibSamples:end);
gyroZ_pix_online =      onlineData.getElement('FCC Data').Values.Internal_Data.gyroZ.Data(calibSamples:end);

figure(i); i = i+1;
plot(tOnline(:),[gyroX_virtual_online(:),gyroX_pix_online(:)])

figure(i); i = i+1;
plot(tOnline(:),[gyroY_virtual_online(:),gyroY_pix_online(:)])

figure(i); i = i+1;
plot(tOnline(:),[gyroZ_virtual_online(:),gyroZ_pix_online(:)])

%% Fin Deflections - Online vs offline
fin1_online = onlineData.getElement('Fin Deflections').Values.Fin_1.Data(calibSamples:end);
fin2_online = onlineData.getElement('Fin Deflections').Values.Fin_2.Data(calibSamples:end);
fin3_online = onlineData.getElement('Fin Deflections').Values.Fin_3.Data(calibSamples:end);
fin4_online = onlineData.getElement('Fin Deflections').Values.Fin_4.Data(calibSamples:end);
fin1_offline = offlineData.getElement('Fin Deflections').Values.Fin_1.Data(:);
fin2_offline = offlineData.getElement('Fin Deflections').Values.Fin_2.Data(:);
fin3_offline = offlineData.getElement('Fin Deflections').Values.Fin_3.Data(:);
fin4_offline = offlineData.getElement('Fin Deflections').Values.Fin_4.Data(:);
% 
% figure(i); i = i+1;
% plot(t(:),[fin1_online(:),fin1_offline(:)])
% 
% figure(i); i = i+1;
% plot(t(:),[fin2_online(:),fin2_offline(:)])
% 
% figure(i); i = i+1;
% plot(t(:),[fin3_online(:),fin3_offline(:)])
% 
% figure(i); i = i+1;
% plot(t(:),[fin4_online(:),fin4_offline(:)])

figure(i); i = i+1;
plot(tOnline(:),[fin1_online(:),fin2_online(:),fin3_online(:),fin4_online(:)],tOffline,fin4_offline(:))

%% Inertial Position - Online vs Offline
x_online = onlineData.getElement('FDM States').Values.POS_NED.POS_x_NED_m.Data(calibSamples:end);
y_online = onlineData.getElement('FDM States').Values.POS_NED.POS_y_NED_m.Data(calibSamples:end);
z_online = -onlineData.getElement('FDM States').Values.POS_NED.POS_z_NED_m.Data(calibSamples:end);
x_offline = offlineData.getElement('FDM States').Values.POS_NED.POS_x_NED_m.Data(:);
y_offline = offlineData.getElement('FDM States').Values.POS_NED.POS_y_NED_m.Data(:);
z_offline = -offlineData.getElement('FDM States').Values.POS_NED.POS_z_NED_m.Data(:);

figure(i); i = i+1;
plot(tOnline(:),x_online(:),tOffline,x_offline(:))

figure(i); i = i+1;
plot(tOnline(:),y_online(:),tOffline,y_offline(:))

figure(i); i = i+1;
plot(tOnline(:),z_online(:),tOffline,z_offline(:))

